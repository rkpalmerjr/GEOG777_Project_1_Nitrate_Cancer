define({
  "_themeLabel": "Motyw Składane",
  "_layout_default": "Kompozycja domyślna",
  "_layout_layout1": "Układ 1"
});