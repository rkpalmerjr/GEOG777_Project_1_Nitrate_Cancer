define({
  "_themeLabel": "Tema Dobrável",
  "_layout_default": "Layout padrão",
  "_layout_layout1": "Layout 1"
});